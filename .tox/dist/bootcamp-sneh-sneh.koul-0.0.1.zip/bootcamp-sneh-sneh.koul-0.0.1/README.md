# People-s-database-flask-app
A flask app using connexion,swagger ,openapi
